#ifndef SIMDELAY_H
#define SIMDELAY_H

#include <stdint.h>

void Delay100Us(uint8_t x);
void DelayMs(uint8_t x);

#endif


